<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {


	function __construct(){
		parent::__construct();
	
		if($this->session->userdata('status') != "login"){
			redirect(redirect(base_url().'index.php/login'));
		}
	}
	public function index()
	{
		
		$this->load->view('admin');
			
		
	}
	function logout(){
		$this->session->sess_destroy();
		redirect(base_url());
	}
	
	
	

}
?>