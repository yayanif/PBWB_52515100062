<h3><?php echo $message; ?></h3>
<p><?php echo anchor(base_url(), 'Return'); ?></p>